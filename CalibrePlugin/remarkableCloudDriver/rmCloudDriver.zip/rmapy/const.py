RFC3339Nano = "%Y-%m-%dT%H:%M:%SZ"
USER_AGENT = "rmapy"
BASE_URL = "https://document-storage-production-dot-remarkable-production.appspot.com"  # noqa
DEVICE_TOKEN_URL = "https://webapp-production-dot-remarkable-production.appspot.com/token/json/2/device/new"
USER_TOKEN_URL = "https://webapp-production-dot-remarkable-production.appspot.com/token/json/2/user/new"
DEVICE = "desktop-windows"
SERVICE_MGR_URL = "https://service-manager-production-dot-remarkable-production.appspot.com"  # noqa
