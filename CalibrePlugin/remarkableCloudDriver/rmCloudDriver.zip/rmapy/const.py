RFC3339Nano = "%Y-%m-%dT%H:%M:%SZ"
USER_AGENT = "rmapy"
AUTH_BASE_URL = "https://webapp-production-dot-remarkable-production.appspot.com"
BASE_URL = "https://document-storage-production-dot-remarkable-production.appspot.com"  # noqa
DEVICE_TOKEN_URL = AUTH_BASE_URL + "/token/json/2/device/new"
USER_TOKEN_URL = AUTH_BASE_URL + "/token/json/2/user/new"
DEVICE = "desktop-windows"
SERVICE_MGR_URL = "https://service-manager-production-dot-remarkable-production.appspot.com"  # noqa