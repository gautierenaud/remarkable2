"""
.. note::
    This is an unofficial api client for the Remarkable Cloud. Use at your own
    risk.
"""
