#!/usr/bin/env python

__license__ = 'GPL v3'
__copyright__ = '2021, Renaud Tamon Gautier <gautierenaud at gmail.com>'
__docformat__ = 'restructuredtext en'

'''
Driver for remarkable 2 tablets, but using the cloud api provided by remarkable. May work on the first gen as well, but
not tested.
'''

from calibre.devices.interface import DevicePlugin

class RemarkableCloudDriver(DevicePlugin):

    name = 'Remarkable 2 Cloud Interface'
    gui_name = 'Remarkable 2'
    description = _('Communicate with Remarkable\'s Cloud API')
    author = 'Renaud Tamon GAUTIER'
    version = (0, 0, 1)

    # only tested on linux though...
    supported_platforms = ['windows', 'osx', 'linux']

    FORMATS = ['epub', 'pdf']